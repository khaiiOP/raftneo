package com.official.raftneo;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.theophrast.ui.widget.*;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class HomeActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> map = new HashMap<>();
	private String charSeq = "";
	private double search_n1 = 0;
	private double search_n = 0;
	private HashMap<String, Object> postMap = new HashMap<>();
	private double n = 0;
	private double PostLike = 0;
	private HashMap<String, Object> lmap = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> listUsers = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listPosts = new ArrayList<>();
	private ArrayList<String> PostKey = new ArrayList<>();
	private ArrayList<String> PChildKey = new ArrayList<>();
	
	private LinearLayout linear1;
	private ImageView imageview3;
	private LinearLayout linear2;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private ImageView imageview1;
	private LinearLayout linear3;
	private ImageView chatpic;
	private ListView listPost;
	private LinearLayout searchbox;
	private ListView listviewSearch;
	private EditText edittext2;
	private ImageView imageview8;
	private ImageView homePic;
	private ImageView searchpic;
	private LinearLayout addbox;
	private ImageView notiPic;
	private CircleImageView avatarbox;
	private ImageView imageview6;
	
	private Intent i = new Intent();
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference userPost = _firebase.getReference("userPost");
	private ChildEventListener _userPost_child_listener;
	private SharedPreferences intents;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		imageview3 = findViewById(R.id.imageview3);
		linear2 = findViewById(R.id.linear2);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		imageview1 = findViewById(R.id.imageview1);
		linear3 = findViewById(R.id.linear3);
		chatpic = findViewById(R.id.chatpic);
		listPost = findViewById(R.id.listPost);
		searchbox = findViewById(R.id.searchbox);
		listviewSearch = findViewById(R.id.listviewSearch);
		edittext2 = findViewById(R.id.edittext2);
		imageview8 = findViewById(R.id.imageview8);
		homePic = findViewById(R.id.homePic);
		searchpic = findViewById(R.id.searchpic);
		addbox = findViewById(R.id.addbox);
		notiPic = findViewById(R.id.notiPic);
		avatarbox = findViewById(R.id.avatarbox);
		imageview6 = findViewById(R.id.imageview6);
		auth = FirebaseAuth.getInstance();
		intents = getSharedPreferences("intents", Activity.MODE_PRIVATE);
		
		edittext2.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				charSeq = _charSeq;
				users.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listUsers = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listUsers.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						if (charSeq.length() > 0) {
							search_n1 = listUsers.size() - 1;
							search_n = listUsers.size();
							for(int _repeat22 = 0; _repeat22 < (int)(search_n); _repeat22++) {
								if (listUsers.get((int)search_n1).get("name").toString().toLowerCase().contains(charSeq.toLowerCase())) {
									
								}
								else {
									listUsers.remove((int)(search_n1));
								}
								search_n1--;
							}
						}
						listviewSearch.setAdapter(new ListviewSearchAdapter(listUsers));
						((BaseAdapter)listviewSearch.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		homePic.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				homePic.setImageResource(R.drawable.home_1);
				searchpic.setImageResource(R.drawable.search_1);
				notiPic.setImageResource(R.drawable.notif_1);
				listPost.setVisibility(View.VISIBLE);
				searchbox.setVisibility(View.GONE);
				listviewSearch.setVisibility(View.GONE);
				chatpic.setVisibility(View.VISIBLE);
			}
		});
		
		searchpic.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				homePic.setImageResource(R.drawable.home_2);
				searchpic.setImageResource(R.drawable.search_2);
				notiPic.setImageResource(R.drawable.notif_1);
				searchbox.setVisibility(View.VISIBLE);
				listviewSearch.setVisibility(View.VISIBLE);
				listPost.setVisibility(View.GONE);
				chatpic.setVisibility(View.GONE);
			}
		});
		
		addbox.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), UserPostActivity.class);
				startActivity(i);
			}
		});
		
		avatarbox.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), ProfileMeActivity.class);
				startActivity(i);
			}
		});
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				users.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listUsers = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listUsers.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avatar").toString())).into(avatarbox);
						}
						listviewSearch.setAdapter(new ListviewSearchAdapter(listUsers));
						((BaseAdapter)listviewSearch.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		_userPost_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				userPost.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listPosts = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listPosts.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						listPost.setAdapter(new ListPostAdapter(listPosts));
						((BaseAdapter)listPost.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		userPost.addChildEventListener(_userPost_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		addbox.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)12, (int)1, 0xFF000000, 0xFF607D8B));
		avatarbox.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c) { this.setStroke(a, b); this.setColor(c); return this; } }.getIns((int)0, Color.TRANSPARENT, Color.TRANSPARENT));
		linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c) { this.setStroke(a, b); this.setColor(c); return this; } }.getIns((int)1, 0xFF000000, 0xFFFFFFFF));
		linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c) { this.setStroke(a, b); this.setColor(c); return this; } }.getIns((int)1, 0xFF000000, 0xFFFFFFFF));
		searchbox.setVisibility(View.GONE);
		listviewSearch.setVisibility(View.GONE);
	}
	
	public class ListPostAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public ListPostAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.homelist, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout upbox = _view.findViewById(R.id.upbox);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView capt = _view.findViewById(R.id.capt);
			final TextView time = _view.findViewById(R.id.time);
			final de.hdodenhof.circleimageview.CircleImageView avtr = _view.findViewById(R.id.avtr);
			final TextView usname = _view.findViewById(R.id.usname);
			final ImageView ver = _view.findViewById(R.id.ver);
			final ImageView postttt = _view.findViewById(R.id.postttt);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			usname.setText(listPosts.get((int)_position).get("name").toString());
			time.setText(listPosts.get((int)_position).get("date").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(listPosts.get((int)_position).get("post").toString())).into(postttt);
			upbox.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c) { this.setStroke(a, b); this.setColor(c); return this; } }.getIns((int)2, 0xFF000000, 0xFFFFFFFF));
			if (listPosts.get((int)_position).containsKey("avatar")) {
				if (listPosts.get((int)_position).get("avatar").toString().equals("")) {
					avtr.setImageResource(R.drawable.guest);
				}
				else {
					Glide.with(getApplicationContext()).load(Uri.parse(listPosts.get((int)_position).get("avatar").toString())).into(avtr);
				}
			}
			else {
				avtr.setImageResource(R.drawable.guest);
			}
			if (listPosts.get((int)_position).containsKey("caption")) {
				if (listPosts.get((int)_position).get("caption").toString().equals("")) {
					capt.setText("No Caption");
				}
				else {
					capt.setText(listPosts.get((int)_position).get("caption").toString());
				}
			}
			else {
				capt.setText("No caption");
			}
			
			return _view;
		}
	}
	
	public class ListviewSearchAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public ListviewSearchAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.search_list, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final TextView usrname = _view.findViewById(R.id.usrname);
			final ImageView ver = _view.findViewById(R.id.ver);
			final TextView biooo = _view.findViewById(R.id.biooo);
			
			usrname.setText(listUsers.get((int)_position).get("name").toString());
			if (listUsers.get((int)_position).containsKey("avatar")) {
				if (listUsers.get((int)_position).get("avatar").toString().equals("")) {
					circleimageview1.setImageResource(R.drawable.guest);
				}
				else {
					Glide.with(getApplicationContext()).load(Uri.parse(listUsers.get((int)_position).get("avatar").toString())).into(circleimageview1);
				}
			}
			else {
				circleimageview1.setImageResource(R.drawable.guest);
			}
			if (listUsers.get((int)_position).containsKey("bio")) {
				if (listUsers.get((int)_position).get("bio").toString().equals("")) {
					biooo.setText("No Bio");
				}
				else {
					biooo.setText(listUsers.get((int)_position).get("bio").toString());
				}
			}
			else {
				biooo.setText("No bio");
			}
			if (listUsers.get((int)_position).containsKey("verify")) {
				if (listUsers.get((int)_position).get("verify").toString().equals("")) {
					ver.setVisibility(View.GONE);
				}
				else {
					ver.setVisibility(View.VISIBLE);
				}
			}
			else {
				ver.setVisibility(View.GONE);
			}
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (listUsers.get((int)_position).get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						i.setClass(getApplicationContext(), ProfileMeActivity.class);
						i.putExtra("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
						startActivity(i);
					}
					else {
						i.setClass(getApplicationContext(), ProfileOtherActivity.class);
						i.putExtra("uid", listUsers.get((int)_position).get("uid").toString());
						intents.edit().putString("profile_other", "search").commit();
						startActivity(i);
					}
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}